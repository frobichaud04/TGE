
#include "mcc_generated_files/mcc.h"
#include "LCD_NHD.h"



void main(void) {

    
    SYSTEM_Initialize();
    ADC_Initialize();
    EUSART1_Initialize();
    
    setContrast(40);
    setBrightness(8);
    

    while (1) {
        ADC_StartConversion(channel_AN9);
        while (ADC_IsConversionDone()) {
            float convertedValue = ((float) ADC_GetConversion(channel_AN9)/4095) * 5;
 
            printf("%.2f V", convertedValue);

            __delay_ms(100);
            clearScreen();
            setCursor(0x40);
        }
    }
}

//hexa des commandes

/*
0xFE 0x41 None    Display on
0xFE 0x42 None    Display off
0xFE 0x45 1 Byte  Set cursor
0xFE 0x46 None    Cursor home
0xFE 0x47 None    Underline cursor on  
0xFE 0x48 None    Underline cursor off  
0xFE 0x49 None    Move cursor left one place  
0xFE 0x4A None    Move cursor right one place  
0xFE 0x4B None    Blinking cursor on  
0xFE 0x4C None    Blinking cursor off  

0xFE 0x4E None    Backspace  
0xFE 0x51 None    Clear screen 
 
0xFE 0x52 1 Byte  Set contrast   
0xFE 0x53 1 Byte  Set backlight brightness  
0xFE 0x54 9 Byte  Load custom character  

0xFE 0x55 None    Move display one place to the left  
0xFE 0x56 None    Move display one place to the right
   
0xFE 0x61 1 Byte  Change RS232 BAUD rate 232
0xFE 0x62 1 Byte  Change I2C address  
0xFE 0x70 None    Display firmware version number   
0xFE 0x71 None    Display RS232 BAUD rate  
0xFE 0x72 None    Display I2C address 
 */

